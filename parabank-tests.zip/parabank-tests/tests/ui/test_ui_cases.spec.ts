import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../pages/RegistrationPage';
import { generateRandomUser } from '../../utils/userGenerator';
import { saveTestData } from '../../utils/testDataHelper';
import { LoginPage } from '../../pages/LoginPage';

test('User registration', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const user = generateRandomUser();
  await registrationPage.navigate();
  await registrationPage.registerUser(user);
  await expect(page.locator('.title')).toHaveText('Welcome ' + user.username1);
  console.log("Sucess!")
});


test('Login and verify global navigation menu', async ({ page }) => {
  // Step 1: Register new user
  const user = generateRandomUser();
  const registrationPage = new RegistrationPage(page);
  await registrationPage.navigate();
  await registrationPage.registerUser(user);

  // Confirm registration
  await expect(page.locator('text=Your account was created successfully')).toBeVisible();

  // Step 2: Login
  const loginPage = new LoginPage(page);
  //await loginPage.login(user.username, user.password);
  

  // Confirm successful login
  await expect(page.locator('text=Accounts Overview')).toBeVisible();
  
  // Step 3: Test Global Navigation Menu
  const navLinks = [
    { label: 'Accounts Overview', path: 'overview.htm', verifyText: 'Accounts Overview' },
    { label: 'Transfer Funds', path: 'transfer.htm', verifyText: 'Transfer Funds' },
  
  ];

  for (const link of navLinks) {
    await page.click(`text=${link.label}`);
    await expect(page.locator(`text=${link.verifyText}`).first()).toBeVisible();
    //await expect(page.getByRole('heading', { name: link.verifyText })).toBeVisible();
    await page.waitForTimeout(5000);
    console.log("Hello8!")
  }

  // Optional: Log out
  await page.click('text=Log Out');
  await expect(page.locator('text=Customer Login')).toBeVisible();
});

test('Create Saving account', async ({ page }) => {
  // Step 1: Register new user
  const user = generateRandomUser();
  const registrationPage = new RegistrationPage(page);
  // await registrationPage.navigate();
  // await registrationPage.registerUser(user);

  // Confirm registration
  // await expect(page.locator('text=Your account was created successfully')).toBeVisible();

  // Step 2: Login
  const loginPage = new LoginPage(page);
  await loginPage.login(user.username1, user.password);

  // Confirm successful login
  // await expect(page.locator('text=Accounts Overview')).toBeVisible();
  // Click the "Open New Account" link from the top navigation menu
  await page.getByRole('link', { name: 'Open New Account' }).click();
  // Verify that the correct heading is visible on the page
  //await page.getByRole('link', { name: 'Open New Account' }).click();
  await page.getByRole('button', { name: 'OPEN NEW ACCOUNT' }).click();
  //await page.getByRole('heading', { name: 'Account Opened!' }).click();
  //await page.getByText('Congratulations, your account').click();
  // ✅ Step 4: Extract and log confirmation message and new account number

  const confirmationMessage = await page.getByRole('heading', { name: 'Account Opened!' }).textContent();
  const accountNumber = await page.locator('a[href^="activity.htm?id="]').textContent();

  console.log('✅ Message:', confirmationMessage?.trim());
  console.log('🆕 New Account Number:', accountNumber?.trim());

  // Optional: Log out
  await page.click('text=Log Out');
  await expect(page.locator('text=Customer Login')).toBeVisible();
});

test('Display balance and transfer fund', async ({ page }) => {
  // Step 1: Register new user
  const user = generateRandomUser();
  const registrationPage = new RegistrationPage(page);
  // await registrationPage.navigate();
  // await registrationPage.registerUser(user);

  // // Confirm registration
  // await expect(page.locator('text=Your account was created successfully')).toBeVisible();

  // Step 2: Login
  const loginPage = new LoginPage(page);
  await loginPage.login(user.username1, user.password);

  // Confirm successful login
  await expect(page.locator('text=Accounts Overview').first()).toBeVisible();
  // Click the "Open New Account" link from the top navigation menu
  await page.getByRole('link', { name: 'Open New Account' }).click();
  // Verify that the correct heading is visible on the page
  const openAccountButton = page.getByRole('button', { name: 'Open New Account' });
  await expect(openAccountButton).toBeVisible();
  await openAccountButton.click();
  // ✅ Step 4: Extract and log confirmation message and new account number
 
  await page.getByRole('link', { name: 'Transfer Funds' }).click();
  await page.locator('#amount').click();
  await page.locator('#amount').fill('100');

  const toAccountDropdown = page.locator('#toAccountId');
  await toAccountDropdown.click();
  await page.locator('#toAccountId').selectOption('16341');
  await page.getByRole('button', { name: 'Transfer' }).click();
  // ✅ Validate heading "Transfer Complete!" is visible
  await expect(page.getByRole('heading', { name: 'Transfer Complete!' })).toBeVisible();

  // ✅ Validate transfer amount message is visible
  await expect(page.getByText('$100.00 has been transferred')).toBeVisible();

  // Optional: Log out
  await page.click('text=Log Out');
  await expect(page.locator('text=Customer Login')).toBeVisible();


});

test('Bill payment processing', async ({ page }) => {
  // Step 1: Register new user
  const user = generateRandomUser();
  const registrationPage = new RegistrationPage(page);
  // await registrationPage.navigate();
  // await registrationPage.registerUser(user);

  // // Confirm registration
  // await expect(page.locator('text=Your account was created successfully')).toBeVisible();

  // Step 2: Login
  const loginPage = new LoginPage(page);
  await loginPage.login(user.username1, user.password);

  // Confirm successful login
  await expect(page.locator('text=Accounts Overview').first()).toBeVisible();
  // Click the "Open New Account" link from the top navigation menu
  await page.getByRole('link', { name: 'Open New Account' }).click();
  // Verify that the correct heading is visible on the page
  const openAccountButton = page.getByRole('button', { name: 'Open New Account' });
  await expect(openAccountButton).toBeVisible();
  await openAccountButton.click();
  // ✅ Step 4: Bill payment and validate
  const accountId = 16119;
  const amount = 100;
  await page.getByRole('link', { name: 'Bill Pay' }).click();
  await page.locator('input[name="payee\\.name"]').click();
  await page.locator('input[name="payee\\.name"]').fill('fashion');
  await page.locator('input[name="payee\\.name"]').press('Tab');
  await page.locator('input[name="payee\\.address\\.street"]').fill('amrapali');
  await page.locator('input[name="payee\\.address\\.street"]').press('Tab');
  await page.locator('input[name="payee\\.address\\.city"]').fill('Noida');
  await page.locator('input[name="payee\\.address\\.city"]').press('Tab');
  await page.locator('input[name="payee\\.address\\.state"]').fill('Uttar Pradesh');
  await page.locator('input[name="payee\\.address\\.state"]').press('Tab');
  await page.locator('input[name="payee\\.address\\.zipCode"]').fill('201304');
  await page.locator('input[name="payee\\.phoneNumber"]').click();
  await page.locator('input[name="payee\\.phoneNumber"]').fill('9161120837');
  await page.locator('input[name="payee\\.accountNumber"]').click();
  await page.locator('input[name="payee\\.accountNumber"]').fill(accountId.toString());
  await page.locator('input[name="payee\\.accountNumber"]').press('Tab');
  await page.locator('input[name="verifyAccount"]').fill(accountId.toString());
  await page.getByRole('row', { name: 'Amount: $' }).getByRole('cell').nth(1).click();
  await page.locator('input[name="amount"]').fill(amount.toString());
  await page.getByRole('button', { name: 'Send Payment' }).click();
  // ✅ Validate heading "Transfer Complete!" is visible
  await expect(page.getByRole('heading', { name: 'Bill Payment Complete' })).toBeVisible();
  // ✅ Validate transfer amount message is visible
  await expect(page.getByText('Bill Payment to fashion in')).toBeVisible();

  // Optional: Log out
  await page.click('text=Log Out');
  await expect(page.locator('text=Customer Login')).toBeVisible();

  saveTestData({
    accountId: Number(accountId),
    transactionAmount: amount,
  });
});
