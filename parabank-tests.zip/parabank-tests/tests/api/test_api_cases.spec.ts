import { test, expect, request } from '@playwright/test';
import { loadTestData } from '../../utils/testDataHelper';

/**
 * Test suite for validating ParaBank API endpoints.
 * Uses Playwright's request context to interact directly with the backend.
 */
test.describe('ParaBank API Tests', () => {
  let apiContext;
  const BASE_URL = 'https://parabank.parasoft.com/parabank';
  let accountId: number;
  let transactionAmount: number;

  /**
   * Runs before all tests.
   * - Loads test data (accountId and transactionAmount) from helper.
   * - Initializes API request context with base URL and headers.
   */
  test.beforeAll(async ({ playwright }) => {
    const data = loadTestData(); // ✅ Load from UI test run
    accountId = data.accountId;
    transactionAmount = data.transactionAmount;

    apiContext = await request.newContext({
      baseURL: BASE_URL,
      extraHTTPHeaders: {
        'Content-Type': 'application/json',
      },
    });
  });

  /**
   * Test Case: Find transactions by a specific amount.
   * 
   * Steps:
   * 1. Sends a GET request to `/services/bank/findtransbyamount` 
   *    with query params (accountId, amount).
   * 2. Asserts HTTP status is 200.
   * 3. Validates that at least one transaction is returned.
   * 4. Confirms the returned transaction has the expected 
   *    accountId and transactionAmount.
   */
  test('Find transactions by amount', async () => {
    const response = await apiContext.get(`/services/bank/findtransbyamount`, {
      params: { accountId, amount: transactionAmount },
    });

    // Verify API call was successful
    expect(response.status()).toBe(200);

    // Parse JSON response
    const responseBody = await response.json();

    // Validate at least one transaction exists
    expect(responseBody.transactions.length).toBeGreaterThan(0);

    // Check first transaction matches expected values
    const transaction = responseBody.transactions[0];
    expect(transaction.amount).toBe(transactionAmount);
    expect(transaction.accountId).toBe(accountId);
  });

  /**
   * Runs after all tests.
   * - Disposes API context to free resources.
   */
  test.afterAll(async () => {
    await apiContext.dispose();
  });
});
