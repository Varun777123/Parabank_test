import { Page, test, expect } from '@playwright/test';

export class LoginPage {
  constructor(private page: Page) {}

async login(username: string, password: string) {
  await this.page.goto('https://parabank.parasoft.com/parabank/index.htm');
  await this.page.waitForLoadState('domcontentloaded');
  // Use label-based selectors
  
  await this.page.locator('input[name="username"]').fill(username);
  await this.page.locator('input[name="password"]').fill(password);
  await this.page.locator('input[value="Log In"]').click();
}
  async isLoginSuccessful(): Promise<boolean> {
    const accountsOverviewLocator = this.page.locator('text=Accounts Overview', { hasText: 'Accounts Overview' }).first();
    await expect(accountsOverviewLocator).toBeVisible();
  }

  async isLoginFailed(): Promise<boolean> {
    return await this.page.locator('text=The username and password could not be verified.').isVisible();
  }
}
