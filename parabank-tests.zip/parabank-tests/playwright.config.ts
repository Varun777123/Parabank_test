import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests', // Directory containing tests
  timeout: 60 * 1000, // Global test timeout (60s)
  expect: {
    timeout: 5000, // Timeout for expect assertions
  },

  // Run tests in parallel
  fullyParallel: true,

  // Retry failing tests
  retries: 2,

  // Opt out of parallel tests on CI
  workers: process.env.CI ? 2 : undefined,

  // Reporter configuration
  reporter: [
    ['list'], // Console reporter
    ['html', { outputFolder: 'playwright-report', open: 'never' }], // HTML report
    ['json', { outputFile: 'test-results.json' }], // JSON results
    ['allure-playwright'], // Allure report (requires allure plugin)
  ],

  use: {
    baseURL: process.env.BASE_URL || 'https://parabank.parasoft.com/',
    headless: true,
    actionTimeout: 15000, // Max time each action can take
    navigationTimeout: 30000,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure', // Collect trace for failed tests
    ignoreHTTPSErrors: true, // Ignore HTTPS errors (if any)
    viewport: { width: 1366, height: 768 },
    launchOptions: {
      slowMo: process.env.CI ? 0 : 50, // Slow down locally for debugging
    },
  },

  // Define multiple browser/device projects
  projects: [
    {
      name: 'Chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'Firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'WebKit',
      use: { ...devices['Desktop Safari'] },
    },   
  ],

  // Output directory for test artifacts (screenshots, traces, videos)
  outputDir: 'test-results/',
});
