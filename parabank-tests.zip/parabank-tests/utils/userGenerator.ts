export function generateRandomUser() {
  const timestamp = Date.now();
  return {
    firstName: 'Test',
    lastName: 'User',
    address: '123 Test St',
    city: 'Testville',
    state: 'TS',
    zipCode: '12345',
    phone: '1234567890',
    ssn: '123-45-6789',
    username: `user_${timestamp}`,
    username1: `user_421`,
    password: 'Password123'
  };
}
