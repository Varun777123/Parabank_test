import * as fs from 'fs';
import * as path from 'path';

const filePath = path.resolve(process.cwd(), 'test-data.json');

export function saveTestData(data: object) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

export function loadTestData() {
  if (!fs.existsSync(filePath)) {
    throw new Error('❌ test-data.json not found. Run UI tests first.');
  }
  const raw = fs.readFileSync(filePath, 'utf-8');
  return JSON.parse(raw);
}
